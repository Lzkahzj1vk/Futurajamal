public interface ProjetRepository extends JpaRepository<Projet, Long> {
    List<Projet> findByStatutOrderByNom(String statut);
}