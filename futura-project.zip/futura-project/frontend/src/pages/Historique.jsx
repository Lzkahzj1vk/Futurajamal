import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import './Historique.css';
import { useNavigate, useSearchParams } from 'react-router-dom';

export default function Historique() {
  const [user, setUser] = useState(null);
  const [projets, setProjets] = useState([]);
  const [saisies, setSaisies] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total_pages: 1, total_saisies: 0, start_index: 0, end_index: 0, page_total_heures: 0 });
  const [filters, setFilters] = useState({ type: '', projet: '', date_debut: '', date_fin: '' });
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    fetch('/api/user', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()).then(setUser);
    fetch('/api/projets', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()).then(setProjets);

    setFilters({
      type: searchParams.get('type') || '',
      projet: searchParams.get('projet') || '',
      date_debut: searchParams.get('date_debut') || '',
      date_fin: searchParams.get('date_fin') || ''
    });

    loadData(1);
  }, [searchParams]);

  const loadData = async (page = 1) => {
    const token = localStorage.getItem('token');
    const params = new URLSearchParams();
    params.append('page', page);
    if (filters.type) params.append('type', filters.type);
    if (filters.projet) params.append('projet', filters.projet);
    if (filters.date_debut) params.append('date_debut', filters.date_debut);
    if (filters.date_fin) params.append('date_fin', filters.date_fin);

    const res = await fetch(`/api/historique?${params}`, { headers: { 'Authorization': 'Bearer ' + token } });
    const data = await res.json();
    setSaisies(data.saisies);
    setPagination(data.pagination);
  };

  const applyFilters = () => {
    const params = new URLSearchParams();
    params.append('page', 1);
    if (filters.type) params.append('type', filters.type);
    if (filters.projet) params.append('projet', filters.projet);
    if (filters.date_debut) params.append('date_debut', filters.date_debut);
    if (filters.date_fin) params.append('date_fin', filters.date_fin);
    setSearchParams(params);
  };

  const resetFilters = () => {
    setFilters({ type: '', projet: '', date_debut: '', date_fin: '' });
    setSearchParams({});
  };

  const deleteSaisie = async (id) => {
    if (!confirm('Supprimer cette saisie?')) return;
    const token = localStorage.getItem('token');
    await fetch(`/api/saisie/${id}`, { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } });
    loadData(pagination.page);
  };

  const formatDate = (s) => {
    if (s.type === 'Congé' && s.conge_date_debut) {
      return `${new Date(s.conge_date_debut).toLocaleDateString('fr-FR')} → ${new Date(s.conge_date_fin).toLocaleDateString('fr-FR')}`;
    }
    return new Date(s.date).toLocaleDateString('fr-FR');
  };

  const formatHeures = (s) => {
    if (s.type === 'Congé') {
      if (s.conge_date_debut && s.conge_date_fin && s.conge_date_debut!== s.conge_date_fin) {
        return s.heures < 24? `${Math.floor(s.heures * 8)}h` : `${s.heures}h`;
      }
      if (s.heures === 1) return '8h';
    }
    return `${s.heures}h`;
  };

  return (
    <Layout user={user} pageTitle="Historique">
      <div className="page-body">
        <div className="hist-card">

          <div className="hist-header">
            <div>
              <h2>Historique des saisies</h2>
              <p>{pagination.total_saisies} enregistrement(s) au total</p>
            </div>
          </div>

          {/* Filter Bar - بدون Export */}
          <div className="filter-bar">
            <div className="filter-row">
              <div className="filter-group">
                <label>Projet / Client</label>
                <select className="filter-select" value={filters.projet} onChange={e => setFilters({...filters, projet: e.target.value})}>
                  <option value="">Tous les projets</option>
                  {projets.map(p => <option key={p.id} value={p.id}>{p.display_name}</option>)}
                </select>
              </div>
              <div className="filter-group">
                <label>Type d'activité</label>
                <select className="filter-select" value={filters.type} onChange={e => setFilters({...filters, type: e.target.value})}>
                  <option value="">Tous les types</option>
                  {['Liste des plans',"Note de Calcul d'Eclairement",'Prises de courant et forces','Synoptiques CFO','Congé','Eclairage','Bilan de puissance'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="filter-group">
                <label>Date de début</label>
                <input type="date" className="filter-input" value={filters.date_debut} onChange={e => setFilters({...filters, date_debut: e.target.value})} />
              </div>
              <div className="filter-group">
                <label>Date de fin</label>
                <input type="date" className="filter-input" value={filters.date_fin} onChange={e => setFilters({...filters, date_fin: e.target.value})} />
              </div>
              <div className="filter-actions">
                <button className="btn-filter" onClick={applyFilters}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="22 3 2 3 10 13 10 21 14 18 14 13 22 3"/>
                  </svg>
                  Filtrer
                </button>
                <button className="btn-reset" onClick={resetFilters}>Réinitialiser</button>
              </div>
            </div>
          </div>

          {saisies.length > 0? (
            <>
              <div style={{overflowX: 'auto'}}>
                <table className="hist-table">
                  <thead>
                    <tr>
                      <th>Date / Période</th>
                      <th>Projet / Client</th>
                      <th>Type</th>
                      <th>Commentaire</th>
                      <th style={{textAlign: 'right'}}>Heures</th>
                      <th style={{textAlign: 'center'}}>Actions</th>
                      <th>Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {saisies.map(s => (
                      <tr key={s.id}>
                        <td style={{color: 'var(--ink-soft)'}}>{formatDate(s)}</td>
                        <td style={{fontWeight: 500}}>{s.projet}</td>
                        <td><span className={`badge ${s.badge_class}`}>{s.type}</span></td>
                        <td style={{color: 'var(--ink-soft)'}}>{s.commentaire || '—'}</td>
                        <td className="td-hours">{formatHeures(s)}</td>
                        <td className="td-actions">
                          <div className="actions-wrap">
                            <button className="btn-edit" onClick={() => navigate(`/saisie/${s.id}`)}>Modifier</button>
                            <button className="btn-danger" onClick={() => deleteSaisie(s.id)}>Supprimer</button>
                          </div>
                        </td>
                        <td>
                          {s.statut === 'en_attente' && <span className="badge" style={{background: '#FEF3C7', color: '#D97706'}}>⏳ En attente</span>}
                          {s.statut === 'valide' && <span className="badge" style={{background: '#D1FAE5', color: '#059669'}}>✓ Validé</span>}
                          {s.statut === 'rejete' && <span className="badge" style={{background: '#FEE2E2', color: '#DC2626'}}>✗ Rejeté</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan="4" style={{padding: '12px 20px', fontSize: '13px', fontWeight: 500, color: 'var(--ink-soft)', borderTop: '2px solid var(--border)', background: 'var(--cream)'}}>
                        Total (page)
                      </td>
                      <td style={{padding: '12px 20px', textAlign: 'right', fontSize: '18px', fontWeight: 300, color: 'var(--ink)', borderTop: '2px solid var(--border)', background: 'var(--cream)'}}>
                        {pagination.page_total_heures}h
                      </td>
                      <td colSpan="2" style={{borderTop: '2px solid var(--border)', background: 'var(--cream)'}}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Pagination */}
              <div className="pagination-wrap">
                <span className="pagination-info">
                  Affichage {pagination.start_index}–{pagination.end_index} sur {pagination.total_saisies} entrées
                </span>
                <div className="pagination-buttons">
                  <button className={`pagination-btn ${pagination.page <= 1? 'disabled' : ''}`}
                    onClick={() => loadData(pagination.page - 1)} disabled={pagination.page <= 1}>
                    ← Préc.
                  </button>

                  {Array.from({length: pagination.total_pages}, (_, i) => i + 1).slice(0, 5).map(p => (
                    <button key={p} className={`pagination-btn ${p === pagination.page? 'active' : ''}`}
                      onClick={() => loadData(p)}>
                      {p}
                    </button>
                  ))}

                  <button className={`pagination-btn ${pagination.page >= pagination.total_pages? 'disabled' : ''}`}
                    onClick={() => loadData(pagination.page + 1)} disabled={pagination.page >= pagination.total_pages}>
                    Suiv. →
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="empty-state">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              <p>Aucune saisie enregistrée pour le moment.</p>
              <button className="btn-primary" onClick={() => navigate('/saisie')}>Créer ma première saisie</button>
            </div>
          )}

        </div>
      </div>
    </Layout>
  );
}