@RestController @RequestMapping("/exporter") @CrossOrigin(origins = "*")
public class RapportsController {

    @Autowired private SaisieRepository saisieRepo;

    @GetMapping("/csv")
    public void exportCSV(@RequestParam Map<String, String> params, HttpServletResponse response, @AuthenticationPrincipal UserDetails user) throws IOException {
        List<Saisie> saisies = getFilteredSaisies(getUserId(user), params);
        
        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=saisies_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".csv");
        response.getWriter().write("\uFEFF");
        
        PrintWriter w = response.getWriter();
        w.println("Date;Type;Projet;Heures;Commentaire;Statut");
        Map<String, String> statutMap = Map.of("en_attente","En attente","valide","Validé","approuve","Approuvé","rejete","Rejeté");
        
        for (Saisie s : saisies) {
            w.printf("%s;%s;%s;%.1f;%s;%s\n",
                s.getDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                s.getTypeActivite(),
                s.getProjetDisplay(),
                s.getHeures(),
                s.getCommentaire() == null ? "" : s.getCommentaire().replace(";", ","),
                statutMap.getOrDefault(s.getStatut(), "En attente")
            );
        }
    }

    private List<Saisie> getFilteredSaisies(Long userId, Map<String, String> p) {
        Specification<Saisie> spec = (root, query, cb) -> cb.equal(root.get("userId"), userId);
        if (p.containsKey("type") && !p.get("type").isBlank()) 
            spec = spec.and((r,q,cb) -> cb.equal(r.get("typeActivite"), p.get("type")));
        if (p.containsKey("projet") && !p.get("projet").isBlank()) 
            spec = spec.and((r,q,cb) -> cb.equal(r.get("projetId"), Long.parseLong(p.get("projet"))));
        if (p.containsKey("date_debut") && !p.get("date_debut").isBlank()) 
            spec = spec.and((r,q,cb) -> cb.greaterThanOrEqualTo(r.get("date"), LocalDate.parse(p.get("date_debut"))));
        if (p.containsKey("date_fin") && !p.get("date_fin").isBlank()) 
            spec = spec.and((r,q,cb) -> cb.lessThanOrEqualTo(r.get("date"), LocalDate.parse(p.get("date_fin"))));
        return saisieRepo.findAll(spec, Sort.by(Sort.Direction.DESC, "date"));
    }
}