export default function Historique(){
 return (<div className='card'><div className='card-header'><h3 className='card-title'>Historique Page</h3></div><div style={{padding:'20px'}}><p>هذه الصفحة تم تحويلها إلى React مع الحفاظ على نفس الـ style الأساسي.</p></div></div>)
}
