@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private SaisieRepository saisieRepo;

    @Autowired
    private ProjetRepository projetRepo;

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard(@AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails); // من JWT
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.with(DayOfWeek.MONDAY);
        LocalDate weekEnd = weekStart.plusDays(6);
        LocalDate monthStart = today.withDayOfMonth(1);

        // نفس queries ديال app.py
        Double heuresSemaine = saisieRepo.sumHeuresByUserAndDateBetween(userId, weekStart, weekEnd);
        Double heuresMois = saisieRepo.sumHeuresByUserAndDateBetween(userId, monthStart, today);
        Long projetsActifs = projetRepo.countByStatut("actif");
        Long saisiesSemaine = saisieRepo.countByUserIdAndDateBetween(userId, weekStart, weekEnd);

        // week_bars نفس logic
        List<Map<String, Object>> weekBars = new ArrayList<>();
        String[] labels = {"Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"};
        for (int i = 0; i < 7; i++) {
            LocalDate d = weekStart.plusDays(i);
            Double h = saisieRepo.sumHeuresByUserAndDate(userId, d);
            Map<String, Object> day = new HashMap<>();
            day.put("label", labels[i]);
            day.put("hours", h!= null? h : 0);
            day.put("today", d.equals(today));
            day.put("weekend", i >= 5);
            weekBars.add(day);
        }

        // recent_saisies نفس query + limit 5
        List<Saisie> recent = saisieRepo.findRecentByUserId(userId, PageRequest.of(0, 5));

        Map<String, Object> res = new HashMap<>();
        res.put("heures_semaine", heuresSemaine!= null? heuresSemaine : 0);
        res.put("heures_mois", heuresMois!= null? heuresMois : 0);
        res.put("projets_actifs", projetsActifs);
        res.put("saisies_semaine", saisiesSemaine);
        res.put("week_bars", weekBars);
        res.put("recent_saisies", recent.stream().map(s -> Map.of(
            "type_activite", s.getTypeActivite(),
            "projet_display", s.getProjet()!= null? s.getProjet().getDisplayName() : "Interne",
            "commentaire", s.getCommentaire(),
            "heures", s.getHeures(),
            "is_today", s.getDate().equals(today),
            "date", s.getDate().format(DateTimeFormatter.ofPattern("dd/MM"))
        )).toList());

        return ResponseEntity.ok(res);
    }
}