import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import './Dashboard.css';
import { Link } from 'react-router-dom';

const dotMap = {
  'Développement': 'dot-blue',
  'Conseil': 'dot-purple',
  'Réunion': 'dot-gray',
  'Formation': 'dot-amber'
};

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // نفس data ديال route / فـ app.py
    const token = localStorage.getItem('token');
    Promise.all([
      fetch('/api/dashboard', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()),
      fetch('/api/user', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json())
    ]).then(([dashData, userData]) => {
      setData(dashData);
      setUser(userData);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    // animate bars نفس JS ديال Flask
    if (!data) return;
    setTimeout(() => {
      document.querySelectorAll('.bar').forEach(b => {
        b.style.height = b.dataset.pct + '%';
      });
    }, 100);
  }, [data]);

  if (loading) return <Layout user={user} pageTitle="Tableau de bord"><div className="page-body">Chargement...</div></Layout>;
  if (!data) return <Layout user={user} pageTitle="Tableau de bord"><div className="page-body">Erreur</div></Layout>;

  const now = new Date();
  const currentDate = now.toLocaleDateString('fr-FR', {day:'2-digit', month:'long'});
  const currentDay = now.toLocaleDateString('fr-FR', {weekday:'long'}) + ' · ' + now.getFullYear();

  return (
    <Layout user={user} pageTitle="Tableau de bord">
      <div className="page-body">
        {/* Welcome - نفس HTML ديال Flask */}
        <div className="welcome-strip">
          <div className="welcome-text">
            <h2>Bonjour, {user?.fullName}</h2>
            <p>Voici un aperçu de votre activité cette semaine</p>
          </div>
          <div style={{textAlign:'right'}}>
            <div className="meta-date">{currentDate}</div>
            <div className="meta-day">{currentDay}</div>
          </div>
        </div>

        {/* Stats - 4 cards نفس structure */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon-wrap blue">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              </div>
            </div>
            <span className="stat-val">{data.heures_semaine.toFixed(1)}h</span>
            <div className="stat-desc">Heures cette semaine</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon-wrap green">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 20h.01M7 20v-4"/><path d="M12 20V10"/><path d="M17 20V4"/></svg>
              </div>
            </div>
            <span className="stat-val">{data.projets_actifs}</span>
            <div className="stat-desc">Projets actifs</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon-wrap amber">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              </div>
              <div className="stat-trend">Ce mois</div>
            </div>
            <span className="stat-val">{data.heures_mois.toFixed(1)}h</span>
            <div className="stat-desc">Heures ce mois</div>
          </div>

          <div className="stat-card">
            <div className="stat-header">
              <div className="stat-icon-wrap purple">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
              </div>
            </div>
            <span className="stat-val">{data.saisies_semaine}</span>
            <div className="stat-desc">Saisies cette semaine</div>
          </div>
        </div>

        {/* Two columns */}
        <div className="two-col">
          <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>

            {/* Week chart - نفس week_bars من app.py */}
            <div className="card">
              <div className="card-header">
                <span className="card-title">Activité de la semaine</span>
                <Link to="/historique" className="card-action">Voir tout</Link>
              </div>
              <div className="week-chart">
                <div className="chart-bars" id="weekBars">
                  {data.week_bars.map((d, i) => {
                    const pct = Math.min((d.hours / 10) * 100, 100);
                    const cls = d.today? 'today' : d.weekend? 'weekend' : '';
                    return (
                      <div className="chart-col" key={i}>
                        <span className="bar-val">{d.hours > 0? d.hours + 'h' : ''}</span>
                        <div className="bar-wrap">
                          <div className={`bar ${cls}`} style={{height:'0%'}} data-pct={pct}></div>
                        </div>
                        <span className="bar-label">{d.label}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="chart-total">
                  <span className="chart-total-label">Total semaine</span>
                  <span className="chart-total-val">{data.heures_semaine.toFixed(1)}h / 40h cible</span>
                </div>
              </div>
            </div>

            {/* Recent saisies - نفس query ديال recent_saisies */}
            <div className="card">
              <div className="card-header">
                <span className="card-title">Dernières saisies</span>
                <Link to="/historique" className="card-action">Historique</Link>
              </div>
              <div>
                {data.recent_saisies.length > 0? data.recent_saisies.map((s, i) => (
                  <div className="activity-item" key={i}>
                    <div className={`activity-dot ${dotMap[s.type_activite] || 'dot-gray'}`}></div>
                    <div className="activity-info">
                      <div className="activity-title">{s.type_activite}</div>
                      <div className="activity-sub">
                        {s.projet_display} {s.commentaire? `— ${s.commentaire}` : ''}
                      </div>
                    </div>
                    <div className="activity-right">
                      <span className="activity-hours">{s.heures}h</span>
                      <span className="activity-date">
                        {s.is_today? "Aujourd'hui" : s.date}
                      </span>
                    </div>
                  </div>
                )) : (
                  <div style={{padding:'24px 20px',color:'var(--ink-faint)',fontSize:'13px'}}>
                    Aucune saisie pour le moment.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: quick actions */}
          <div className="card" style={{alignSelf:'start'}}>
            <div className="card-header">
              <span className="card-title">Actions rapides</span>
            </div>
            <div className="quick-actions">
              <Link to="/saisie" className="quick-btn">
                <div className="quick-icon blue">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>
                </div>
                <div>
                  <span className="quick-title">Nouvelle saisie</span>
                  <span className="quick-desc">Enregistrer votre activité</span>
                </div>
              </Link>
              <Link to="/conge" className="quick-btn">
                <div className="quick-icon amber">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                </div>
                <div>
                  <span className="quick-title">Demande de congé</span>
                  <span className="quick-desc">Soumettre une demande</span>
                </div>
              </Link>
              <Link to="/historique" className="quick-btn">
                <div className="quick-icon green">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="12 8 12 12 14 14"/><path d="M3.05 11a9 9 0 1 0.5-4"/><polyline points="3 3 3 7 7 7"/></svg>
                </div>
                <div>
                  <span className="quick-title">Historique</span>
                  <span className="quick-desc">Consulter vos saisies</span>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}