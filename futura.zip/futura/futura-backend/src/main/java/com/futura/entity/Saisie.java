package com.futura.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "saisies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Saisie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String typeActivite;
    private Double heures;
    private String commentaire;
    private String statut;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "projet_id")
    private Projet projet;
}
