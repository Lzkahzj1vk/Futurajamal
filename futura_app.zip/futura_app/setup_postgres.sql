-- ══════════════════════════════════════════
--  Futura Expertise — PostgreSQL Setup
--  Run once as superuser (e.g. postgres)
-- ══════════════════════════════════════════

-- 1. Create role
CREATE ROLE futura_user WITH LOGIN PASSWORD 'futura_pass';

-- 2. Create database
CREATE DATABASE futura_db OWNER futura_user;

-- 3. Grant privileges
GRANT ALL PRIVILEGES ON DATABASE futura_db TO futura_user;

-- ══════════════════════════════════════════
--  Connect to futura_db then run:
--  \c futura_db
-- ══════════════════════════════════════════

-- Tables are created automatically by SQLAlchemy (db.create_all())
-- via the `flask init-db` command or on first app run.

-- Optional: to reset everything
-- DROP DATABASE IF EXISTS futura_db;
-- DROP ROLE IF EXISTS futura_user;
