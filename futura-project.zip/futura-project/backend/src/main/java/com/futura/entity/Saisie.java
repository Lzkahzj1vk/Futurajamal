@Entity @Table(name = "saisies")
public class Saisie {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(name = "type_activite", nullable = false, length = 100)
    private String typeActivite;
    
    @Column(name = "projet_id")
    private Long projetId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projet_id", insertable = false, updatable = false)
    private Projet projet;
    
    @Column(precision = 5, scale = 2, nullable = false)
    private Double heures;
    
    @Column(columnDefinition = "TEXT")
    private String commentaire;
    
    @Column(length = 20)
    private String statut = "en_attente";
    
    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
    
    // Champs congé
    @Column(name = "conge_date_debut")
    private LocalDate congeDateDebut;
    
    @Column(name = "conge_date_fin") 
    private LocalDate congeDateFin;
    
    @Transient
    public String getProjetDisplay() {
        return projet != null ? projet.getDisplayName() : "Interne";
    }
}