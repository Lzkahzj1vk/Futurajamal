import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './styles.css';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Saisie from './pages/Saisie';
import Historique from './pages/Historique';
import Conge from './pages/Conge';
function App(){return (<BrowserRouter><Routes><Route path='/' element={<Login/>}/><Route element={<Layout/>}><Route path='/dashboard' element={<Dashboard/>}/><Route path='/saisie' element={<Saisie/>}/><Route path='/historique' element={<Historique/>}/><Route path='/conge' element={<Conge/>}/></Route></Routes></BrowserRouter>)}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
