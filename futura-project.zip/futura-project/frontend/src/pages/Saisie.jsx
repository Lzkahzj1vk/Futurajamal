import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import './Saisie.css';
import { useNavigate, useParams, Link } from 'react-router-dom';

export default function Saisie() {
  const [projets, setProjets] = useState([]);
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({
    projet_id: '',
    date: new Date().toISOString().split('T')[0],
    type_activite: '',
    heures: '',
    commentaire: '',
    conge_duree_type: '1jour',
    conge_date_debut: '',
    conge_date_fin: '',
    conge_heures_1jour: '8'
  });
  const [isConge, setIsConge] = useState(false);
  const [nbJours, setNbJours] = useState('—');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const { id } = useParams(); // pour edit

  useEffect(() => {
    const token = localStorage.getItem('token');
    Promise.all([
      fetch('/api/projets', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()),
      fetch('/api/user', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json())
    ]).then(([projData, userData]) => {
      setProjets(projData);
      setUser(userData);
    });

    if (id) {
      // mode edit - نفس /saisie/<id>/edit
      fetch(`/api/saisie/${id}`, { headers: { 'Authorization': 'Bearer ' + token } })
       .then(r => r.json())
       .then(s => {
          const isCongeType = s.type_activite === 'Congé';
          setForm({
            projet_id: s.projet_id || '',
            date: s.date,
            type_activite: s.type_activite,
            heures: s.heures,
            commentaire: s.commentaire || '',
            conge_duree_type: s.conge_date_debut && s.conge_date_fin? 'multi' : '1jour',
            conge_date_debut: s.conge_date_debut || '',
            conge_date_fin: s.conge_date_fin || '',
            conge_heures_1jour: isCongeType && s.heures <= 8? s.heures : '8'
          });
          setIsConge(isCongeType);
        });
    }
  }, [id]);

  useEffect(() => {
    // نفس logic JS ديال Flask: afficher/masquer champs congé
    const conge = form.type_activite === 'Congé';
    setIsConge(conge);

    if (conge) {
      if (form.conge_duree_type === 'multi') {
        if (form.conge_date_debut && form.conge_date_fin && form.conge_date_fin >= form.conge_date_debut) {
          const d1 = new Date(form.conge_date_debut);
          const d2 = new Date(form.conge_date_fin);
          const diff = Math.ceil(Math.abs(d2 - d1) / 86400000) + 1;
          setNbJours(diff);
          setForm(f => ({...f, heures: diff }));
        } else {
          setNbJours('—');
          setForm(f => ({...f, heures: '' }));
        }
      } else {
        setForm(f => ({...f, heures: form.conge_heures_1jour }));
      }
    }
  }, [form.type_activite, form.conge_duree_type, form.conge_date_debut, form.conge_date_fin, form.conge_heures_1jour]);

  const isWeekend = (dateStr) => {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    return d.getUTCDay() === 0 || d.getUTCDay() === 6;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {};

    // validation week-end نفس Flask
    if (!isConge && isWeekend(form.date)) {
      newErrors.date = 'Les samedis et dimanches ne sont pas autorisés.';
    }
    if (isConge && form.conge_duree_type === 'multi') {
      if (isWeekend(form.conge_date_debut)) newErrors.conge_date_debut = 'Les samedis et dimanches ne sont pas autorisés.';
      if (isWeekend(form.conge_date_fin)) newErrors.conge_date_fin = 'Les samedis et dimanches ne sont pas autorisés.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setTimeout(() => setErrors({}), 3000);
      return;
    }

    const token = localStorage.getItem('token');
    const url = id? `/api/saisie/${id}` : '/api/saisie';
    const method = id? 'PUT' : 'POST';

    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify(form)
    });
    navigate('/historique');
  };

  const selectCongeDuree = (val) => {
    setForm(f => ({...f, conge_duree_type: val }));
  };

  return (
    <Layout user={user} pageTitle={id? 'Modifier la saisie' : 'Nouvelle saisie'}>
      <div className="page-body">
        <div className="form-card">
          <div className="form-card-header">
            <div className="form-header-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="22" height="22">
                {id? <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/> : <path d="M12 5v14M5 12h14"/>}
              </svg>
            </div>
            <div>
              <h2>{id? 'Modifier la saisie' : 'Enregistrer votre activité'}</h2>
              <p>{id? 'Mettez à jour les informations de cette saisie.' : 'Renseignez votre activité du jour.'}</p>
            </div>
          </div>

          <div className="form-body">
            <form onSubmit={handleSubmit}>

              <div className="form-section-label">Informations générales</div>

              {/* Projet - caché si Congé */}
              {!isConge && (
                <div className="form-group">
                  <label htmlFor="projet_id">Projet</label>
                  <select id="projet_id" value={form.projet_id} onChange={e => setForm({...form, projet_id: e.target.value})} className="form-control">
                    <option value="">Interne / Hors projet</option>
                    {projets.map(p => <option key={p.id} value={p.id}>{p.display_name}</option>)}
                  </select>
                </div>
              )}

              <div className="form-grid-2">
                {/* Date - يختفي فحالة plusieurs jours */}
                {!(isConge && form.conge_duree_type === 'multi') && (
                  <div className="form-group">
                    <label htmlFor="date">Date <span className="label-req">*</span></label>
                    <input type="date" id="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} className="form-control" required />
                    {errors.date && <small style={{color:'#e53e3e'}}>⚠ {errors.date}</small>}
                  </div>
                )}

                {/* Type d'activité */}
                <div className="form-group">
                  <label htmlFor="type_activite">Type d'activité <span className="label-req">*</span></label>
                  <select id="type_activite" value={form.type_activite} onChange={e => setForm({...form, type_activite: e.target.value})} className="form-control" required>
                    <option value="">— Sélectionner —</option>
                    {['Liste des plans',"Note de Calcul d'Eclairement",'Prises de courant et forces','Synoptiques CFO','Carnet des câbles CFO','Bilan de puissance','Note de Calcul BT','Note de Calcul MT','Note de Calcul DC','Note de Calcul Batterie','Note de Calcul CDC','Note de Calcul de mise à la terre','Bilan Thermique','Note de Calcul paratonnerre','Eclairage','Réseau sous dallage','Réservations','Plans des locaux techniques','Mise à la terre et protection foudre','Plans CDC','Plans des locaux types','Réseau extérieur','Photovoltaïque','Schémas des tableaux','Synoptiques CFA','Réseau wifi','Sonorisation','Audiovisuel','Précâblage informatique','Système sécurité incendie','Vidéosurveillance',"Contrôle d'accès et d'intrusion","Gestion d'éclairage",'Aménagement local PCS','Carnet des câbles CFA','Gestion domotique','GTC','TBE','Congé'].map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              {/* Heures - caché si Congé */}
              {!isConge && (
                <div className="form-group">
                  <label htmlFor="heures">Nombre d'heures <span className="label-req">*</span></label>
                  <input type="number" id="heures" value={form.heures} onChange={e => setForm({...form, heures: e.target.value})} className="form-control" min="0.5" max="24" step="0.5" placeholder="ex: 4.5" required />
                </div>
              )}

              {/* Champs Congé */}
              {isConge && (
                <div className="conge-dates">
                  <div className="conge-label">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Durée du congé
                  </div>

                  {/* Radio buttons */}
                  <div className="conge-radio-group">
                    <div className={`conge-radio-btn ${form.conge_duree_type === '1jour'? 'active' : ''}`} onClick={() => selectCongeDuree('1jour')}>
                      <div className="radio-circle"></div>
                      <div className="radio-text">
                        <span className="radio-title">≤ 1 jour</span>
                        <span className="radio-sub">Demi-journée / journée</span>
                      </div>
                    </div>
                    <div className={`conge-radio-btn ${form.conge_duree_type === 'multi'? 'active' : ''}`} onClick={() => selectCongeDuree('multi')}>
                      <div className="radio-circle"></div>
                      <div className="radio-text">
                        <span className="radio-title">Plusieurs jours</span>
                        <span className="radio-sub">Date début → Date fin</span>
                      </div>
                    </div>
                  </div>
                  <input type="hidden" name="conge_duree_type" value={form.conge_duree_type} />

                  {/* Mode 1 jour */}
                  {form.conge_duree_type === '1jour' && (
                    <div className="form-group">
                      <div className="nb-jours-display" style={{marginBottom:'6px'}}>
                        <span className="nb-val" style={{fontSize:'15px',minWidth:'auto'}}>ℹ</span>
                        <span className="nb-lbl">1 jour</span>
                      </div>
                      <label htmlFor="conge_heures_1jour">Nombre d'heures <span className="label-req">*</span></label>
                      <input type="number" id="conge_heures_1jour" value={form.conge_heures_1jour} onChange={e => setForm({...form, conge_heures_1jour: e.target.value})} className="form-control" min="0.5" max="8" step="0.5" placeholder="ex: 8" required />
                    </div>
                  )}

                  {/* Mode plusieurs jours */}
                  {form.conge_duree_type === 'multi' && (
                    <>
                      <div className="form-grid-2">
                        <div className="form-group">
                          <label htmlFor="conge_date_debut">Date début <span className="label-req">*</span></label>
                          <input type="date" id="conge_date_debut" value={form.conge_date_debut} onChange={e => setForm({...form, conge_date_debut: e.target.value})} className="form-control" required />
                          {errors.conge_date_debut && <small style={{color:'#e53e3e'}}>⚠ {errors.conge_date_debut}</small>}
                        </div>
                        <div className="form-group">
                          <label htmlFor="conge_date_fin">Date fin <span className="label-req">*</span></label>
                          <input type="date" id="conge_date_fin" value={form.conge_date_fin} onChange={e => setForm({...form, conge_date_fin: e.target.value})} className="form-control" required />
                          {errors.conge_date_fin && <small style={{color:'#e53e3e'}}>⚠ {errors.conge_date_fin}</small>}
                        </div>
                      </div>
                      <div className="form-group">
                        <label>Durée calculée</label>
                        <div className="nb-jours-display">
                          <span className="nb-val">{nbJours}</span>
                          <span className="nb-lbl">jour(s) de congé</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Commentaire */}
              <div className="form-section-label" style={{marginTop:'8px'}}>Commentaire</div>
              <div className="form-group">
                <label htmlFor="commentaire">Description</label>
                <textarea id="commentaire" value={form.commentaire} onChange={e => setForm({...form, commentaire: e.target.value})} className="form-control" rows="4" placeholder="Décrivez brièvement votre activité…"></textarea>
              </div>

              <div className="form-actions">
                <button type="submit" className="btn-primary">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>
                  {id? 'Mettre à jour' : 'Enregistrer la saisie'}
                </button>
                <Link to="/historique" className="btn-secondary">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="15" height="15"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  Annuler
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}