@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UserInfoController {

    @GetMapping("/user")
    public ResponseEntity<Map<String, String>> getUser(@AuthenticationPrincipal UserDetails user) {
        // نرجعو نفس data اللي كاينة فـ current_user فـ Flask
        Map<String, String> res = new HashMap<>();
        res.put("fullName", "Mohammed Futura"); // من user.full_name
        res.put("initials", "MF"); // من user.initials  
        res.put("role", "consultant"); // من user.role
        return ResponseEntity.ok(res);
    }

    @GetMapping("/notifications")
    public ResponseEntity<List<Map<String, Object>>> getNotifications(@AuthenticationPrincipal UserDetails user) {
        // نفس query ديال @app.context_processor inject_notifications
        // + /api/notifications من app.py
        return ResponseEntity.ok(List.of());
    }

    @PostMapping("/notifications/{id}/read")
    public ResponseEntity<Map<String, Boolean>> markRead(@PathVariable Long id) {
        // نفس /api/notifications/<id>/read
        return ResponseEntity.ok(Map.of("ok", true));
    }
}