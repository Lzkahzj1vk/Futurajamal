public interface SaisieRepository extends JpaRepository<Saisie, Long>, JpaSpecificationExecutor<Saisie> {
    List<Saisie> findByUserIdOrderByDateDescCreatedAtDesc(Long userId);
    Optional<Saisie> findByIdAndUserId(Long id, Long userId);
}