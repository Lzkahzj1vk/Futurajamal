import { useState } from 'react'

export default function Login() {
  const [email, setEmail] = useState('admin@futura.com')
  const [password, setPassword] = useState('1234')
  const [message, setMessage] = useState('')

  const handleLogin = async (e) => {
    e.preventDefault()

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      })

      const data = await response.json()

      if (data.success) {
        localStorage.setItem('token', data.token)
        setMessage('✅ Login successful')
      } else {
        setMessage('❌ ' + data.message)
      }
    } catch (error) {
      setMessage('❌ Backend connection error')
    }
  }

  return (
    <div className='card'>
      <div className='card-header'>
        <h3 className='card-title'>Login</h3>
      </div>

      <div style={{ padding: '20px' }}>
        <form onSubmit={handleLogin}>
          <input
            type='email'
            placeholder='Email'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
          />

          <input
            type='password'
            placeholder='Password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
          />

          <button
            type='submit'
            style={{ padding: '10px 20px', cursor: 'pointer' }}>
            Login
          </button>
        </form>

        {message && (
          <p style={{ marginTop: '15px' }}>
            {message}
          </p>
        )}
      </div>
    </div>
  )
}
