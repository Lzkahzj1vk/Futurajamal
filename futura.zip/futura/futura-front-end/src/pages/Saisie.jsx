export default function Saisie(){
 return (<div className='card'><div className='card-header'><h3 className='card-title'>Saisie Page</h3></div><div style={{padding:'20px'}}><p>هذه الصفحة تم تحويلها إلى React مع الحفاظ على نفس الـ style الأساسي.</p></div></div>)
}
