# Futura Expertise — Flask + PostgreSQL

## هيكل المشروع

```
futura_app/
├── app.py                  ← التطبيق الرئيسي (Flask + Models + Routes)
├── requirements.txt        ← المكتبات المطلوبة
├── setup_postgres.sql      ← إعداد قاعدة البيانات
└── templates/
    ├── base.html           ← القالب الأساسي (sidebar + topbar + notifications)
    ├── login.html          ← صفحة تسجيل الدخول
    ├── dashboard.html      ← لوحة التحكم الرئيسية
    ├── saisie.html         ← نموذج إدخال الساعات
    ├── historique.html     ← سجل السيزيات
    └── conge.html          ← طلب إجازة
```

---

## الإعداد خطوة بخطوة

### 1. تثبيت PostgreSQL
```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib -y
sudo systemctl start postgresql
```

### 2. إنشاء قاعدة البيانات
```bash
sudo -u postgres psql -f setup_postgres.sql
```

### 3. تثبيت المكتبات Python
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 4. تشغيل التطبيق
```bash
python app.py
```
سيتم إنشاء الجداول تلقائياً وإدخال بيانات تجريبية عند أول تشغيل.

افتح المتصفح على: **http://localhost:5000**

---

## بيانات الدخول التجريبية

| الحقل | القيمة |
|-------|--------|
| Email | youssef@futura.ma |
| Mot de passe | futura2026 |

---

## متغيرات البيئة (للإنتاج)

```bash
export SECRET_KEY="your-super-secret-key"
export DATABASE_URL="postgresql://futura_user:futura_pass@localhost:5432/futura_db"
```

---

## نموذج البيانات (Models)

| الجدول | الوصف |
|--------|-------|
| `users` | المستخدمون (consultant / admin) |
| `projets` | المشاريع |
| `saisies` | سجلات الساعات |
| `conges` | طلبات الإجازات |
| `notifications` | الإشعارات |

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET/POST | `/login` | تسجيل الدخول |
| GET | `/logout` | تسجيل الخروج |
| GET | `/` | Dashboard |
| GET/POST | `/saisie` | إضافة سيزية |
| GET/POST | `/saisie/<id>/edit` | تعديل سيزية |
| POST | `/saisie/<id>/delete` | حذف سيزية |
| GET | `/historique` | سجل السيزيات |
| GET/POST | `/conge` | طلب إجازة |
| GET | `/api/notifications` | JSON notifications |
| POST | `/api/notifications/<id>/read` | تحديد كمقروء |
| POST | `/api/notifications/read-all` | تحديد الكل كمقروء |
