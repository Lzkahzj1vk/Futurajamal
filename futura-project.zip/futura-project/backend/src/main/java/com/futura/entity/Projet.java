@Entity @Table(name = "projets")
public class Projet {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 200)
    private String nom;
    
    @Column(length = 50)
    private String codeProjet;
    
    @Column(length = 100)
    private String client;
    
    @Column(length = 20)
    private String statut = "actif";
    
    @Column(name = "date_creation")
    private LocalDateTime dateCreation = LocalDateTime.now();
    
    public String getDisplayName() {
        return (codeProjet != null ? codeProjet + " - " : "") + nom + (client != null ? " (" + client + ")" : "");
    }
}