@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CongeController {

    @Autowired
    private CongeRepository congeRepo;

    @GetMapping("/conges")
    public List<Conge> getConges(Authentication auth) {
        Long userId = getUserId(auth);
        return congeRepo.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @PostMapping("/conge")
    public ResponseEntity<?> createConge(@RequestBody Map<String, Object> body, Authentication auth) {
        Long userId = getUserId(auth);
        
        LocalDate dateDebut = LocalDate.parse((String) body.get("date_debut"));
        LocalDate dateFin = LocalDate.parse((String) body.get("date_fin"));
        
        // Validation week-end même que Flask
        if (dateDebut.getDayOfWeek().getValue() >= 6 || dateFin.getDayOfWeek().getValue() >= 6) {
            return ResponseEntity.badRequest().body("Les dates de congé ne peuvent pas tomber un samedi ou dimanche.");
        }
        
        Conge c = new Conge();
        c.setUserId(userId);
        c.setTypeConge((String) body.get("type_conge"));
        c.setDateDebut(dateDebut);
        c.setDateFin(dateFin);
        c.setNbJours(Integer.parseInt(body.get("nb_jours").toString()));
        c.setMotif((String) body.get("motif"));
        c.setStatut("en_attente");
        c.setCreatedAt(LocalDateTime.now());
        
        congeRepo.save(c);
        
        // Notification comme Flask
        // notificationService.create(userId, "Demande de congé envoyée", "Demande de " + c.getNbJours() + " jour(s) soumise, en attente d'approbation.", "amber");
        
        return ResponseEntity.ok().build();
    }
}