@RestController @RequestMapping("/api") @CrossOrigin(origins = "*")
public class HistoriqueController {

    @Autowired private SaisieRepository saisieRepo;

    @GetMapping("/historique")
    public Map<String, Object> getHistorique(
        @RequestParam(defaultValue = "1") int page,
        @RequestParam(required = false) String type,
        @RequestParam(required = false) String projet,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date_debut,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date_fin,
        @AuthenticationPrincipal UserDetails user
    ) {
        Long userId = getUserId(user);
        int pageSize = 20;

        Specification<Saisie> spec = (root, query, cb) -> cb.equal(root.get("userId"), userId);
        if (type!= null &&!type.isBlank()) spec = spec.and((r,q,cb) -> cb.equal(r.get("typeActivite"), type));
        if (projet!= null &&!projet.isBlank()) spec = spec.and((r,q,cb) -> cb.equal(r.get("projetId"), Long.parseLong(projet)));
        if (date_debut!= null) spec = spec.and((r,q,cb) -> cb.greaterThanOrEqualTo(r.get("date"), date_debut));
        if (date_fin!= null) spec = spec.and((r,q,cb) -> cb.lessThanOrEqualTo(r.get("date"), date_fin));

        Pageable pageable = PageRequest.of(page - 1, pageSize, Sort.by(Sort.Direction.DESC, "date", "createdAt"));
        Page<Saisie> pageData = saisieRepo.findAll(spec, pageable);

        List<Map<String, Object>> saisies = pageData.getContent().stream().map(s -> Map.of(
            "id", s.getId(),
            "date", s.getDate().toString(),
            "type", s.getTypeActivite(),
            "projet", s.getProjetDisplay(),
            "heures", s.getHeures(),
            "commentaire", s.getCommentaire() == null? "" : s.getCommentaire(),
            "statut", s.getStatut(),
            "badge_class", getBadgeClass(s.getTypeActivite()),
            "conge_date_debut", s.getCongeDateDebut(),
            "conge_date_fin", s.getCongeDateFin()
        )).toList();

        double pageTotal = pageData.getContent().stream().mapToDouble(Saisie::getHeures).sum();
        int startIdx = (page - 1) * pageSize + 1;
        int endIdx = Math.min(startIdx + pageSize - 1, (int)pageData.getTotalElements());

        return Map.of(
            "saisies", saisies,
            "pagination", Map.of(
                "page", page,
                "total_pages", pageData.getTotalPages(),
                "total_saisies", pageData.getTotalElements(),
                "start_index", startIdx,
                "end_index", endIdx,
                "page_total_heures", Math.round(pageTotal * 10.0) / 10.0
            )
        );
    }

    @DeleteMapping("/saisie/{id}")
    public ResponseEntity<?> deleteSaisie(@PathVariable Long id, @AuthenticationPrincipal UserDetails user) {
        Long userId = getUserId(user);
        Saisie s = saisieRepo.findByIdAndUserId(id, userId).orElse(null);
        if (s == null) return ResponseEntity.notFound().build();
        saisieRepo.delete(s);
        return ResponseEntity.ok().build();
    }

    private String getBadgeClass(String type) {
        return switch(type) {
            case "Eclairage" -> "badge-yellow";
            case "Bilan de puissance" -> "badge-purple";
            case "Congé" -> "badge-green";
            default -> "badge-blue";
        };
    }

    private Long getUserId(UserDetails user) {
        // نفس logic ديال app.py current_user.id
        return Long.parseLong(user.getUsername());
    }
}