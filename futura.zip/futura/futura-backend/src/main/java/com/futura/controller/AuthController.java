package com.futura.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String password = payload.get("password");

        Map<String, Object> response = new HashMap<>();

        if ("admin@futura.com".equals(email) && "1234".equals(password)) {
            response.put("success", true);
            response.put("message", "Login successful");
            response.put("token", "futura-demo-token");
            response.put("user", email);
        } else {
            response.put("success", false);
            response.put("message", "Email ou mot de passe incorrect");
        }

        return response;
    }
}
