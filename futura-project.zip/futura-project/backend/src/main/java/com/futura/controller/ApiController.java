@RestController @RequestMapping("/api") @CrossOrigin(origins = "*")
public class ApiController {

    @Autowired private SaisieRepository saisieRepo;
    @Autowired private ProjetRepository projetRepo;
    @Autowired private CongeRepository congeRepo;

    @GetMapping("/saisies")
    public List<Map<String, Object>> getSaisies(
        @RequestParam(required = false) String type,
        @RequestParam(required = false) String projet,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date_debut,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date_fin,
        @AuthenticationPrincipal UserDetails user
    ) {
        Long userId = getUserId(user);
        
        Specification<Saisie> spec = (root, query, cb) -> cb.equal(root.get("userId"), userId);
        
        if (type != null && !type.isBlank()) 
            spec = spec.and((r,q,cb) -> cb.equal(r.get("typeActivite"), type));
        if (projet != null && !projet.isBlank()) 
            spec = spec.and((r,q,cb) -> cb.equal(r.get("projetId"), Long.parseLong(projet)));
        if (date_debut != null) 
            spec = spec.and((r,q,cb) -> cb.greaterThanOrEqualTo(r.get("date"), date_debut));
        if (date_fin != null) 
            spec = spec.and((r,q,cb) -> cb.lessThanOrEqualTo(r.get("date"), date_fin));
        
        return saisieRepo.findAll(spec, Sort.by(Sort.Direction.DESC, "date", "createdAt"))
            .stream().map(s -> Map.of(
                "id", s.getId(),
                "date", s.getDate().toString(),
                "type", s.getTypeActivite(),
                "projet", s.getProjetDisplay(),
                "heures", s.getHeures(),
                "commentaire", s.getCommentaire() == null ? "" : s.getCommentaire(),
                "statut", s.getStatut(),
                "conge_date_debut", s.getCongeDateDebut(),
                "conge_date_fin", s.getCongeDateFin()
            )).toList();
    }

    @GetMapping("/projets")
    public List<Map<String, Object>> getProjets() {
        return projetRepo.findByStatutOrderByNom("actif")
            .stream().map(p -> Map.of("id", p.getId(), "display_name", p.getDisplayName()))
            .toList();
    }

    @PostMapping("/saisie")
    public ResponseEntity<?> createSaisie(@RequestBody Map<String, Object> body, @AuthenticationPrincipal UserDetails user) {
        // نفس logic ديال app.py /saisie POST
        Long userId = getUserId(user);
        String type = (String) body.get("type_activite");
        
        Saisie s = new Saisie();
        s.setUserId(userId);
        s.setTypeActivite(type);
        s.setCommentaire((String) body.get("commentaire"));
        s.setStatut("en_attente");
        
        if ("Congé".equals(type)) {
            if ("multi".equals(body.get("conge_duree_type"))) {
                LocalDate debut = LocalDate.parse((String) body.get("conge_date_debut"));
                LocalDate fin = LocalDate.parse((String) body.get("conge_date_fin"));
                if (debut.getDayOfWeek().getValue() >= 6 || fin.getDayOfWeek().getValue() >= 6)
                    return ResponseEntity.badRequest().body("Week-end non autorisé");
                s.setDate(debut);
                s.setCongeDateDebut(debut);
                s.setCongeDateFin(fin);
                s.setHeures((double)(ChronoUnit.DAYS.between(debut, fin) + 1));
            } else {
                s.setDate(LocalDate.parse((String) body.get("date")));
                s.setHeures(Double.parseDouble(body.get("conge_heures_1jour").toString()));
            }
        } else {
            s.setDate(LocalDate.parse((String) body.get("date")));
            s.setHeures(Double.parseDouble(body.get("heures").toString()));
            Object pid = body.get("projet_id");
            s.setProjetId(pid != null && !pid.toString().isEmpty() ? Long.parseLong(pid.toString()) : null);
        }
        
        if (s.getDate().getDayOfWeek().getValue() >= 6)
            return ResponseEntity.badRequest().body("La date ne peut pas être un week-end");
            
        saisieRepo.save(s);
        return ResponseEntity.ok(Map.of("id", s.getId()));
    }
}