@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class SaisieController {

    @Autowired
    private SaisieRepository saisieRepo;

    @Autowired
    private ProjetRepository projetRepo;

    @GetMapping("/projets")
    public List<Projet> getProjets() {
        return projetRepo.findByStatutOrderByNom("actif");
    }

    @PostMapping("/saisie")
    public ResponseEntity<?> createSaisie(@RequestBody Map<String, Object> body, @AuthenticationPrincipal UserDetails user) {
        Long userId = getUserId(user);
        String typeActivite = (String) body.get("type_activite");

        Saisie s = new Saisie();
        s.setUserId(userId);
        s.setTypeActivite(typeActivite);
        s.setCommentaire((String) body.get("commentaire"));
        s.setStatut("en_attente");

        if ("Congé".equals(typeActivite)) {
            String dureeType = (String) body.get("conge_duree_type");
            if ("multi".equals(dureeType)) {
                LocalDate debut = LocalDate.parse((String) body.get("conge_date_debut"));
                LocalDate fin = LocalDate.parse((String) body.get("conge_date_fin"));
                if (debut.getDayOfWeek().getValue() >= 6 || fin.getDayOfWeek().getValue() >= 6) {
                    return ResponseEntity.badRequest().body("Les dates de congé ne peuvent pas tomber un samedi ou un dimanche.");
                }
                int nbJours = (int) ChronoUnit.DAYS.between(debut, fin) + 1;
                s.setDate(debut);
                s.setHeures((double) nbJours);
                s.setCongeDateDebut(debut);
                s.setCongeDateFin(fin);
            } else {
                s.setDate(LocalDate.parse((String) body.get("date")));
                s.setHeures(Double.parseDouble(body.get("conge_heures_1jour").toString()));
            }
            s.setProjetId(null);
        } else {
            s.setDate(LocalDate.parse((String) body.get("date")));
            s.setHeures(Double.parseDouble(body.get("heures").toString()));
            Object projetId = body.get("projet_id");
            s.setProjetId(projetId!= null &&!projetId.toString().isEmpty()? Long.parseLong(projetId.toString()) : null);
        }

        if (s.getDate().getDayOfWeek().getValue() >= 6) {
            return ResponseEntity.badRequest().body("La date saisie ne peut pas tomber un samedi ou un dimanche.");
        }

        saisieRepo.save(s);
        // Notification نفس app.py
        return ResponseEntity.ok().build();
    }

    @GetMapping("/saisie/{id}")
    public Saisie getSaisie(@PathVariable Long id, @AuthenticationPrincipal UserDetails user) {
        return saisieRepo.findByIdAndUserId(id, getUserId(user)).orElseThrow();
    }

    @PutMapping("/saisie/{id}")
    public ResponseEntity<?> updateSaisie(@PathVariable Long id, @RequestBody Map<String, Object> body, @AuthenticationPrincipal UserDetails user) {
        Saisie s = saisieRepo.findByIdAndUserId(id, getUserId(user)).orElseThrow();
        // نفس logic create
        saisieRepo.save(s);
        return ResponseEntity.ok().build();
    }
}