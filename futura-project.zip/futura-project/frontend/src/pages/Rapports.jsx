import React, { useEffect, useState, useRef } from 'react';
import Layout from '../components/Layout';
import './Rapports.css';

export default function Rapports() {
  const [user, setUser] = useState(null);
  const [projets, setProjets] = useState([]);
  const [saisies, setSaisies] = useState([]);
  const [conges, setConges] = useState([]);
  
  const [filters, setFilters] = useState({
    type: '',
    projet: '',
    date_debut: '',
    date_fin: ''
  });
  
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const exportRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    Promise.all([
      fetch('/api/user', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()),
      fetch('/api/projets', { headers: { 'Authorization': 'Bearer ' + token } }).then(r => r.json()),
      loadData()
    ]).then(([userData, projData]) => {
      setUser(userData);
      setProjets(projData);
    });

    document.addEventListener('click', (e) => {
      if (exportRef.current && !exportRef.current.contains(e.target)) {
        setExportMenuOpen(false);
      }
    });
  }, []);

  const loadData = async () => {
    const token = localStorage.getItem('token');
    const [saisiesRes, congesRes] = await Promise.all([
      fetch('/api/saisies', { headers: { 'Authorization': 'Bearer ' + token } }),
      fetch('/api/conges', { headers: { 'Authorization': 'Bearer ' + token } })
    ]);
    setSaisies(await saisiesRes.json());
    setConges(await congesRes.json());
  };

  const filterSaisies = async () => {
    const token = localStorage.getItem('token');
    const params = new URLSearchParams();
    if (filters.type) params.append('type', filters.type);
    if (filters.projet) params.append('projet', filters.projet);
    if (filters.date_debut) params.append('date_debut', filters.date_debut);
    if (filters.date_fin) params.append('date_fin', filters.date_fin);
    
    const res = await fetch(`/api/saisies?${params}`, { headers: { 'Authorization': 'Bearer ' + token } });
    setSaisies(await res.json());
  };

  const resetFilters = () => {
    setFilters({ type: '', projet: '', date_debut: '', date_fin: '' });
    loadData();
  };

  const exportSaisies = (format) => {
    const params = new URLSearchParams();
    if (filters.type) params.append('type', filters.type);
    if (filters.projet) params.append('projet', filters.projet);
    if (filters.date_debut) params.append('date_debut', filters.date_debut);
    if (filters.date_fin) params.append('date_fin', filters.date_fin);
    window.location.href = `/exporter/${format}?${params}`;
    setExportMenuOpen(false);
  };

  const totalHeures = saisies.reduce((sum, s) => sum + parseFloat(s.heures || 0), 0);
  const totalSaisies = saisies.length;
  const enAttente = saisies.filter(s => s.statut === 'en_attente').length;
  const pendingCount = enAttente;

  const formatDate = (dateStr) => {
    if (!dateStr || dateStr === 'null') return '—';
    const d = new Date(dateStr);
    return d.toLocaleDateString('fr-FR');
  };

  const formatHeures = (h) => {
    const num = parseFloat(h);
    return Number.isInteger(num) ? num + 'h' : num.toFixed(1) + 'h';
  };

  return (
    <Layout user={user} pageTitle="Rapports & Analyses">
      <div className="page-body">

        {/* Export Bar */}
        <div className="export-bar">
          <div className="export-dropdown" ref={exportRef}>
            <button id="exportSaisiesBtn" className="btn-exporter" onClick={() => setExportMenuOpen(!exportMenuOpen)}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
              </svg>
              Exporter Saisies ▼
            </button>
            <div id="exportSaisiesMenu" className={`export-menu ${exportMenuOpen ? 'show' : ''}`}>
              <div className="export-menu-label">Saisies uniquement</div>
              <a href="#" onClick={(e) => {e.preventDefault(); exportSaisies('csv')}}>
                <span className="file-icon csv-icon"><svg viewBox="0 0 24 24"><text x="12" y="17" textAnchor="middle" fontSize="6">CSV</text></svg></span>
                CSV (.csv)
              </a>
              <a href="#" onClick={(e) => {e.preventDefault(); exportSaisies('xlsx')}}>
                <span className="file-icon excel-icon"><svg viewBox="0 0 24 24"><path d="M9 10l4 6M13 10l-4 6" stroke="currentColor" strokeWidth="2"/></svg></span>
                Excel (.xlsx)
              </a>
              <a href="#" onClick={(e) => {e.preventDefault(); exportSaisies('pdf')}}>
                <span className="file-icon pdf-icon"><svg viewBox="0 0 24 24"><text x="12" y="17" textAnchor="middle" fontSize="6">PDF</text></svg></span>
                PDF (.pdf)
              </a>
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="section-header">
          <div className="section-title">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
              <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
            </svg>
            Historique des saisies
          </div>
        </div>

        {/* Pending Notice */}
        {pendingCount > 0 && (
          <div className="pending-notice">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{pendingCount} saisie(s) en attente d'approbation.</span>
          </div>
        )}

        {/* Filters */}
        <div className="filter-bar">
          <div className="filter-row">
            <div className="filter-group">
              <label>Projet / Client</label>
              <select className="filter-select" value={filters.projet} 
                onChange={e => setFilters({...filters, projet: e.target.value})}>
                <option value="">Tous les projets</option>
                {projets.map(p => <option key={p.id} value={p.id}>{p.display_name}</option>)}
              </select>
            </div>
            <div className="filter-group">
              <label>Type d'activité</label>
              <select className="filter-select" value={filters.type}
                onChange={e => setFilters({...filters, type: e.target.value})}>
                <option value="">Tous les types</option>
                {Object.keys(Saisie.BADGE_MAP || {}).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="filter-group">
              <label>Date début</label>
              <input type="date" className="filter-input" value={filters.date_debut}
                onChange={e => setFilters({...filters, date_debut: e.target.value})} />
            </div>
            <div className="filter-group">
              <label>Date fin</label>
              <input type="date" className="filter-input" value={filters.date_fin}
                onChange={e => setFilters({...filters, date_fin: e.target.value})} />
            </div>
            <div className="filter-actions">
              <button className="btn-filter" onClick={filterSaisies}>Filtrer</button>
              <button className="btn-reset" onClick={resetFilters}>Réinitialiser</button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="stats-mini">
          <div className="stat-mini">
            <span className="stat-val">{formatHeures(totalHeures)}</span>
            <div className="stat-desc">Total heures</div>
          </div>
          <div className="stat-mini">
            <span className="stat-val">{totalSaisies}</span>
            <div className="stat-desc">Nombre de saisies</div>
          </div>
          <div className="stat-mini">
            <span className="stat-val">{enAttente}</span>
            <div className="stat-desc">En attente d'approbation</div>
          </div>
        </div>

        {/* Table */}
        <div className="card">
          <div style={{overflowX: 'auto'}}>
            <table className="rapport-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Projet / Client</th>
                  <th>Type</th>
                  <th>Commentaire</th>
                  <th style={{textAlign: 'right'}}>Heures</th>
                  <th style={{textAlign: 'center'}}>Statut</th>
                </tr>
              </thead>
              <tbody>
                {saisies.length === 0 ? (
                  <tr className="empty-row"><td colSpan="6">Aucune saisie trouvée</td></tr>
                ) : saisies.map(s => {
                  const isConge = s.type === 'Congé';
                  const dateDisplay = isConge && s.conge_date_debut && s.conge_date_fin
                    ? `${formatDate(s.conge_date_debut)} → ${formatDate(s.conge_date_fin)}`
                    : formatDate(s.date);

                  const statutClass = `status-${s.statut || 'en_attente'}`;
                  const statutLabel = {
                    'en_attente': '⏳ En attente',
                    'approuve': '✓ Validé',
                    'valide': '✓ Validé',
                    'refuse': '✗ Rejeté',
                    'rejete': '✗ Rejeté'
                  }[s.statut] || '⏳ En attente';

                  return (
                    <tr key={s.id}>
                      <td>{dateDisplay}</td>
                      <td>{s.projet || 'Interne'}</td>
                      <td><span className="badge badge-blue">{s.type}</span></td>
                      <td style={{color: 'var(--ink-soft)', maxWidth: '220px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}} title={s.commentaire}>
                        {s.commentaire || '—'}
                      </td>
                      <td style={{textAlign: 'right', fontWeight: 500}}>{formatHeures(s.heures)}</td>
                      <td style={{textAlign: 'center'}}><span className={`status-badge ${statutClass}`}>{statutLabel}</span></td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan="4">Total heures</td>
                  <td style={{textAlign: 'right'}}>{formatHeures(totalHeures)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

      </div>
    </Layout>
  );
}