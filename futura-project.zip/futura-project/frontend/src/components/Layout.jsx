import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Layout.css';

export default function Layout({ children, user, pageTitle }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState([]);
  const notifRef = useRef(null);
  const location = useLocation();

  useEffect(() => {
    fetch('/api/notifications', {
      headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') }
    })
    .then(res => res.json())
    .then(setNotifs);
  }, []);

  useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target) && !e.target.closest('#notifBtn')) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const markOneRead = (id) => {
    fetch(`/api/notifications/${id}/read`, { 
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') }
    });
    setNotifs(notifs.map(n => n.id === id ? {...n, lu: true} : n));
  };

  const markAllRead = () => {
    fetch('/api/notifications/read-all', { 
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') }
    });
    setNotifs(notifs.map(n => ({...n, lu: true})));
  };

  const notifUnread = notifs.filter(n => !n.lu).length;

  const navItems = [
    { label: 'Principal', items: [
      { path: '/dashboard', icon: 'grid', text: 'Tableau de bord' },
      { path: '/saisie', icon: 'plus', text: 'Nouvelle saisie' },
      { path: '/historique', icon: 'history', text: 'Historique' },
    ]},
    { label: 'Gestion', items: [
      { path: '/conge', icon: 'calendar', text: 'Demande de congé' },
      { path: '/rapports', icon: 'file', text: 'Rapports' },
    ]}
  ];

  const Icon = ({name}) => {
    const icons = {
      grid: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>,
      plus: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>,
      history: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="12 8 12 12 14 14"/><path d="M3.05 11a9 9 0 1 0 .5-4"/><polyline points="3 3 3 7 7 7"/></svg>,
      calendar: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
      file: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>,
      bell: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
      menu: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>,
      logout: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
    };
    return icons[name] || null;
  };

  return (
    <div className="app">
      <div id="menuOverlay" className={`menu-overlay ${sidebarOpen ? 'active' : ''}`} onClick={() => setSidebarOpen(false)}></div>

      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-brand">
          <img src="/logo-futura.png" alt="Futura Expertise" style={{height: '50px', width: 'auto', objectFit: 'contain'}} />
        </div>

        {navItems.map((section, i) => (
          <div className="nav-section" key={i}>
            <span className="nav-label">{section.label}</span>
            {section.items.map(item => (
              <Link 
                to={item.path} 
                className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
                key={item.path}
              >
                <Icon name={item.icon} />
                {item.text}
              </Link>
            ))}
          </div>
        ))}

        <div className="nav-section">
          <span className="nav-label">Compte</span>
          <Link to="/logout" className="nav-item">
            <Icon name="logout" />
            Déconnexion
          </Link>
        </div>

        <div className="sidebar-footer">
          <div className="user-card">
            <div className="avatar">{user?.initials || '??'}</div>
            <div style={{flex:1, minWidth:0}}>
              <span className="user-name">{user?.fullName || 'User'}</span>
              <span className="user-role">{user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1) || 'Consultant'}</span>
            </div>
          </div>
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div style={{display:'flex', alignItems:'center'}}>
            <button className="hamburger-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Icon name="menu" />
            </button>
            <div className="page-title">{pageTitle}</div>
          </div>

          <div className="topbar-right">
            <div style={{position:'relative'}} ref={notifRef}>
              <button className="topbar-btn" onClick={(e) => {e.stopPropagation(); setNotifOpen(!notifOpen)}} id="notifBtn">
                <Icon name="bell" />
                {notifUnread > 0 && <span className="notif-badge"></span>}
              </button>
              <div className={`notif-popover ${notifOpen ? 'active' : ''}`}>
                <div className="notif-header">
                  <span className="notif-header-title">Notifications</span>
                  <span className="notif-header-action" onClick={markAllRead}>Tout marquer comme lu</span>
                </div>
                <div className="notif-list">
                  {notifs.map(n => (
                    <div className={`notif-item ${!n.lu ? 'unread' : ''}`} key={n.id} onClick={() => markOneRead(n.id)}>
                      <div className={`notif-dot-sm ${n.couleur}`}></div>
                      <div className="notif-content">
                        <div className="notif-title">{n.titre}</div>
                        <div className="notif-desc">{n.description}</div>
                      </div>
                      <span className="notif-time">{n.time}</span>
                    </div>
                  ))}
                </div>
                <div className="notif-footer"><a href="#">Voir toutes →</a></div>
              </div>
            </div>

            <Link to="/saisie" className="btn-add">
              <Icon name="plus" />
              Nouvelle saisie
            </Link>
          </div>
        </div>

        <div className="page-body">
          {children}
        </div>
      </main>
    </div>
  );
}