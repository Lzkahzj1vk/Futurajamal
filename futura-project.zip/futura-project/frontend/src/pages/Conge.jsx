import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import './Conge.css';
import { useNavigate } from 'react-router-dom';

export default function Conge() {
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({
    type_conge: '',
    date_debut: '',
    date_fin: '',
    motif: '',
    nb_jours: ''
  });
  const [conges, setConges] = useState([]);
  const [filter, setFilter] = useState('all');
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    fetch('/api/user', { headers: { 'Authorization': 'Bearer ' + token } })
      .then(r => r.json()).then(setUser);
    
    fetch('/api/conges', { headers: { 'Authorization': 'Bearer ' + token } })
      .then(r => r.json()).then(setConges);
  }, []);

  const calcDays = (d1, d2) => {
    if (d1 && d2) {
      const diff = (new Date(d2) - new Date(d1)) / (1000*60*60*24) + 1;
      if (diff > 0) setForm(f => ({...f, nb_jours: diff}));
    }
  };

  const isWeekend = (dateStr) => {
    const d = new Date(dateStr);
    return d.getUTCDay() === 0 || d.getUTCDay() === 6;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isWeekend(form.date_debut) || isWeekend(form.date_fin)) {
      alert('Les samedis et dimanches ne sont pas autorisés.');
      return;
    }
    
    const token = localStorage.getItem('token');
    const res = await fetch('/api/conge', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify(form)
    });
    if (res.ok) navigate('/dashboard');
  };

  const filteredConges = conges.filter(c => filter === 'all' || c.statut === filter);

  const stats = {
    en_attente: conges.filter(c => c.statut === 'en_attente').length,
    approuve: conges.filter(c => c.statut === 'approuve').length,
    total_jours: conges.reduce((sum, c) => sum + c.nb_jours, 0)
  };

  return (
    <Layout user={user} pageTitle="Demande de congé">
      <div className="page-body">
        <div className="conge-grid">

          {/* Form */}
          <div className="form-card">
            <div className="form-card-header">
              <h2>Nouvelle demande de congé</h2>
              <p>Soumettez votre demande pour validation.</p>
            </div>
            <div className="form-body">
              <form onSubmit={handleSubmit}>

                <div className="form-group">
                  <label>Type de congé *</label>
                  <select className="form-control" required
                    value={form.type_conge} 
                    onChange={e => setForm({...form, type_conge: e.target.value})}>
                    <option value="">— Sélectionner —</option>
                    <option value="Congé annuel">Congé annuel</option>
                    <option value="Congé maladie">Congé maladie</option>
                    <option value="Congé sans solde">Congé sans solde</option>
                    <option value="Congé exceptionnel">Congé exceptionnel</option>
                    <option value="RTT">RTT</option>
                  </select>
                </div>

                <div className="form-grid-2">
                  <div className="form-group">
                    <label>Date de début *</label>
                    <input type="date" className="form-control" required
                      value={form.date_debut}
                      onChange={e => {
                        const val = e.target.value;
                        setForm({...form, date_debut: val});
                        calcDays(val, form.date_fin);
                      }} />
                    {isWeekend(form.date_debut) && 
                      <small className="error-text">⚠ Les samedis et dimanches ne sont pas autorisés.</small>}
                  </div>
                  <div className="form-group">
                    <label>Date de fin *</label>
                    <input type="date" className="form-control" required
                      value={form.date_fin}
                      onChange={e => {
                        const val = e.target.value;
                        setForm({...form, date_fin: val});
                        calcDays(form.date_debut, val);
                      }} />
                    {isWeekend(form.date_fin) && 
                      <small className="error-text">⚠ Les samedis et dimanches ne sont pas autorisés.</small>}
                  </div>
                </div>

                <div className="form-group">
                  <label>Nombre de jours *</label>
                  <input type="number" className="form-control" min="1"
                    placeholder="Calculé automatiquement"
                    value={form.nb_jours}
                    onChange={e => setForm({...form, nb_jours: e.target.value})} required />
                </div>

                <div className="form-group">
                  <label>Motif (optionnel)</label>
                  <textarea className="form-control" rows="3"
                    placeholder="Précisez le motif si nécessaire…"
                    value={form.motif}
                    onChange={e => setForm({...form, motif: e.target.value})}></textarea>
                </div>

                <div className="form-actions">
                  <button type="submit" className="btn-primary">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                      <path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>
                    </svg>
                    Envoyer la demande
                  </button>
                  <button type="button" className="btn-secondary" onClick={() => navigate('/dashboard')}>Annuler</button>
                </div>

              </form>
            </div>
          </div>

          {/* History Sidebar */}
          <div className="history-card">
            <div className="history-header">
              <h3>Mes demandes</h3>
            </div>

            {/* Stats */}
            <div className="stats-bar">
              <div className="stat-box">
                <span className="stat-label">En attente</span>
                <div className="stat-value" style={{color: '#D97706'}}>{stats.en_attente}</div>
              </div>
              <div className="stat-box">
                <span className="stat-label">Approuvés</span>
                <div className="stat-value" style={{color: '#059669'}}>{stats.approuve}</div>
              </div>
              <div className="stat-box">
                <span className="stat-label">Total jours</span>
                <div className="stat-value" style={{color: 'var(--ink)'}}>{stats.total_jours}</div>
              </div>
            </div>

            {/* Filters */}
            <div className="filter-bar">
              <button className={`filter-btn ${filter==='all'?'active':''}`} onClick={() => setFilter('all')}>Toutes</button>
              <button className={`filter-btn ${filter==='en_attente'?'active':''}`} onClick={() => setFilter('en_attente')}>⏳ En attente</button>
              <button className={`filter-btn ${filter==='approuve'?'active':''}`} onClick={() => setFilter('approuve')}>✓ Approuvés</button>
              <button className={`filter-btn ${filter==='refuse'?'active':''}`} onClick={() => setFilter('refuse')}>✗ Refusés</button>
            </div>

            {/* List */}
            {filteredConges.length > 0 ? filteredConges.map(c => (
              <div className="conge-item" key={c.id} data-status={c.statut}>
                <div className={`conge-dot ${c.statut}`}></div>
                <div className="conge-info">
                  <div className="conge-type">{c.type_conge}</div>
                  <div className="conge-dates">
                    {new Date(c.date_debut).toLocaleDateString('fr-FR')} → {new Date(c.date_fin).toLocaleDateString('fr-FR')}
                    · {c.nb_jours} jour(s)
                  </div>
                  {c.motif && 
                    <div className="conge-motif">📝 {c.motif.length > 50 ? c.motif.slice(0,50)+'...' : c.motif}</div>}
                  <div className="conge-date">📅 Demandé le {new Date(c.created_at).toLocaleDateString('fr-FR')}</div>
                </div>
                <span className={`status-badge ${c.statut}`}>
                  {c.statut === 'en_attente' && '⏳ En attente'}
                  {c.statut === 'approuve' && '✓ Approuvé'}
                  {c.statut === 'refuse' && '✗ Refusé'}
                </span>
              </div>
            )) : (
              <div className="empty-state">Aucune demande pour le moment.</div>
            )}
          </div>

        </div>
      </div>
    </Layout>
  );
}